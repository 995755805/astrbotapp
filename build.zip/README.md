# IP连接器 APK 构建包

## 📱 应用信息
- **应用名称**: IP连接器
- **包名**: com.example.ipconnector
- **版本**: 1.0.0
- **开发者**: IP连接器开发团队

## 🚀 构建APK的方法

### 方法1: PhoneGap Build (推荐)
1. 访问 [https://build.phonegap.com/](https://build.phonegap.com/)
2. 注册/登录账户
3. 点击 "Upload a .zip file"
4. 将 `build` 目录中的所有文件打包成ZIP文件上传
5. 等待构建完成并下载APK

### 方法2: Cordova CLI (需要Android SDK)
```bash
# 安装Android SDK后运行
cordova build android
```

### 方法3: Android Studio
1. 打开Android Studio
2. 选择 "Open an existing Android Studio project"
3. 选择 `platforms/android` 目录
4. 点击 "Build" -> "Build Bundle(s) / APK(s)" -> "Build APK(s)"

### 方法4: 在线构建服务
- **Ionic Appflow**: https://ionicframework.com/appflow
- **Capacitor**: https://capacitorjs.com/
- **Cordova Build**: https://build.cordova.io/

## 📁 文件结构
```
build/
├── www/                    # 应用源代码
│   ├── splash.html         # 启动页
│   ├── webview.html        # WebView显示页
│   ├── settings.html       # 设置页
│   ├── about.html          # 关于我们页
│   ├── error.html          # 错误页
│   ├── manifest.json       # PWA配置
│   ├── sw.js              # Service Worker
│   └── assets/            # 静态资源
│       ├── icons/         # 应用图标
│       └── static/        # UI框架文件
├── config.xml             # Cordova配置
└── package.json           # 项目配置
```

## 🔧 配置说明

### 应用权限
- 网络访问权限
- 存储权限
- 设备信息权限

### 目标平台
- Android 5.1+ (API Level 22+)
- 支持ARM和x86架构

### 图标尺寸
- 16x16px 到 512x512px
- 支持所有Android密度

## 📲 安装说明

1. **启用未知来源**: 在Android设备上启用"允许安装未知来源的应用"
2. **传输APK**: 将APK文件传输到Android设备
3. **安装应用**: 点击APK文件进行安装
4. **启动应用**: 安装完成后点击应用图标启动

## 🛠️ 自定义开发

### 修改应用信息
编辑 `config.xml` 文件：
```xml
<widget id="com.example.ipconnector" version="1.0.0">
    <name>你的应用名称</name>
    <description>应用描述</description>
    <author email="your@email.com">你的名字</author>
</widget>
```

### 修改应用图标
替换 `www/assets/icons/` 目录中的图标文件，保持文件名不变。

### 修改应用功能
编辑 `www/` 目录中的HTML文件来修改应用功能。

## 📞 技术支持

- **邮箱**: 995755805@qq.com
- **问题反馈**: 通过应用内"关于我们"页面联系

## 📄 许可证

本项目采用MIT许可证。

---

**注意**: 构建APK需要有效的开发者证书。对于发布到Google Play Store，需要注册Google Play开发者账户。
